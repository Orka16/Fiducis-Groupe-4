<?php
// Extrait de /var/www/nextcloud/config/config.php — journalisation des accès (CNIL)
// Activer d'abord : occ app:enable admin_audit
$CONFIG = [
  // Journal dédié à l'audit des accès aux fichiers clients
  'logfile'       => '/var/log/nextcloud/audit.log',
  'logdateformat' => 'Y-m-d H:i:s',
  'loglevel'      => 1,                    // 1 = info (capture les accès)
  'log_type'      => 'file',

  // Restreindre la journalisation à l'application d'audit
  'log.condition' => [
    'apps' => ['admin_audit'],
  ],

  // Rétention applicative (rotation gérée par logrotate, cf. ci-dessous)
];
