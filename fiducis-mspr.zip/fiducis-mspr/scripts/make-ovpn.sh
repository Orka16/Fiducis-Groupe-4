#!/usr/bin/env bash
# make-ovpn.sh <utilisateur> — génère le certificat et le profil .ovpn d'un télétravailleur
set -euo pipefail
USER="${1:?Usage: make-ovpn.sh <utilisateur>  (ex: tt-jdupont)}"
EASYRSA_DIR="$HOME/easyrsa"
OUT="$HOME/profils-ovpn"
mkdir -p "$OUT"

cd "$EASYRSA_DIR"
EASYRSA_BATCH=1 ./easyrsa gen-req "$USER" nopass
EASYRSA_BATCH=1 ./easyrsa sign-req client "$USER"

PKI="$EASYRSA_DIR/pki"
{
  cat <<TPL
client
dev tun
proto udp
remote 203.0.113.11 1195
resolv-retry infinite
nobind
remote-cert-tls server
cipher AES-256-GCM
auth SHA256
tls-version-min 1.2
persist-key
persist-tun
verb 3
key-direction 1
TPL
  echo "<ca>";       cat "$PKI/ca.crt";                 echo "</ca>"
  echo "<cert>";     cat "$PKI/issued/$USER.crt";       echo "</cert>"
  echo "<key>";      cat "$PKI/private/$USER.key";       echo "</key>"
  echo "<tls-auth>"; cat "$EASYRSA_DIR/ta.key";          echo "</tls-auth>"
} > "$OUT/$USER.ovpn"

echo "Profil prêt : $OUT/$USER.ovpn"
