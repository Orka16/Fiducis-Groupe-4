#!/usr/bin/env bash
# init-pki.sh — Génère la PKI OpenVPN (CA + certificats hub/spokes) sur GW-BDX
set -euo pipefail

sudo apt-get update
sudo apt-get install -y openvpn easy-rsa

EASYRSA_DIR="$HOME/easyrsa"
make-cadir "$EASYRSA_DIR"
cd "$EASYRSA_DIR"

./easyrsa init-pki
EASYRSA_BATCH=1 ./easyrsa build-ca nopass

# Serveur (hub)
EASYRSA_BATCH=1 ./easyrsa gen-req bordeaux nopass
EASYRSA_BATCH=1 ./easyrsa sign-req server bordeaux

# Spokes (agences)
for site in larochelle bayonne; do
  EASYRSA_BATCH=1 ./easyrsa gen-req "$site" nopass
  EASYRSA_BATCH=1 ./easyrsa sign-req client "$site"
done

# Diffie-Hellman + clé TLS d'auth
./easyrsa gen-dh
openvpn --genkey secret ta.key

echo "PKI générée dans $EASYRSA_DIR/pki"
echo "Pensez à distribuer ca.crt + ta.key + (cert/key propre) à chaque spoke."
