#!/usr/bin/env bash
# provision-virtualbox.sh — crée le réseau "Internet" et les VM de la maquette FIDUCIS
# Prérequis : VirtualBox installé, ISO Debian/Windows dans ~/iso
set -euo pipefail
ISO_DIR="$HOME/iso"
VMDIR="$HOME/VirtualBox VMs"

# --- Réseau "Internet" simulé (NAT Network, plage publique de doc) ---
VBoxManage natnetwork add --netname inet-sim --network "203.0.113.0/24" --enable --dhcp off || true

# --- Fonction utilitaire : crée une VM Debian routeur/serveur ---
create_debian () {
  local VM="$1" RAM="$2"; shift 2
  VBoxManage createvm --name "$VM" --ostype Debian_64 --register
  VBoxManage modifyvm "$VM" --memory "$RAM" --cpus 1 --paravirtprovider default
  VBoxManage createhd --filename "$VMDIR/$VM/$VM.vdi" --size 12000 --variant Standard
  VBoxManage storagectl "$VM" --name SATA --add sata --controller IntelAhci
  VBoxManage storageattach "$VM" --storagectl SATA --port 0 --device 0 --type hdd --medium "$VMDIR/$VM/$VM.vdi"
  VBoxManage storageattach "$VM" --storagectl SATA --port 1 --device 0 --type dvddrive --medium "$ISO_DIR/debian-12-netinst.iso"
}

# --- Passerelles ---
create_debian GW-BDX 512
VBoxManage modifyvm GW-BDX --nic1 natnetwork --nat-network1 inet-sim
VBoxManage modifyvm GW-BDX --nic2 intnet --intnet2 lan-bdx
VBoxManage modifyvm GW-BDX --nic3 intnet --intnet3 dmz-bdx

create_debian GW-LR 512
VBoxManage modifyvm GW-LR --nic1 natnetwork --nat-network1 inet-sim
VBoxManage modifyvm GW-LR --nic2 intnet --intnet2 lan-lr

create_debian GW-BAY 512
VBoxManage modifyvm GW-BAY --nic1 natnetwork --nat-network1 inet-sim
VBoxManage modifyvm GW-BAY --nic2 intnet --intnet2 lan-bay

# --- Serveurs Linux (LAN Bordeaux / DMZ) ---
create_debian SRV-NEXTCLOUD 2048
VBoxManage modifyvm SRV-NEXTCLOUD --memory 2048 --nic1 intnet --intnet1 lan-bdx

create_debian SRV-WEB 512
VBoxManage modifyvm SRV-WEB --nic1 intnet --intnet1 dmz-bdx

echo "VM Debian créées. Les VM Windows (SRV-AD, SRV-VEEAM, SRV-SAGE, SRV-DC2, clients)"
echo "se créent de la même façon avec --ostype Windows2022_64 et l'ISO correspondant."
echo "Rappel réseaux : lan-bdx / dmz-bdx / lan-lr / lan-bay (Internal Networks auto-créés)."
