# 09 — Conformité RGPD & traçabilité CNIL

Le 2ᵉ entretien introduit un **contrôle CNIL** et l'exigence de **traçabilité des accès aux données clients** : être capable de répondre à *« qui a accédé à quel dossier, et quand ? »*. L'internalisation (sortie de OneDrive) est ce qui rend cette traçabilité possible — on ne maîtrisait pas les journaux du cloud.

## 9.1 Principes RGPD mobilisés

| Principe | Traduction technique chez FIDUCIS |
|---|---|
| Minimisation / moindre privilège | Groupes AD par service (Compta, Juridique, RH) ; chacun n'accède qu'à son périmètre |
| Intégrité & confidentialité | Chiffrement (VPN, HTTPS, BitLocker/LUKS, sauvegardes AES-256) |
| Traçabilité / responsabilité | Journalisation des accès (Nextcloud `admin_audit`, audit NTFS, logs VPN nominatifs) |
| Conservation limitée | Rétention des journaux bornée (cf. §9.5) |
| Disponibilité | Sauvegarde 3-2-1 + PRA/PCA |

## 9.2 Traçabilité des accès aux fichiers — Nextcloud

L'application **`admin_audit`** journalise chaque évènement (consultation, téléchargement, création, modification, partage, suppression) avec **utilisateur + horodatage + IP**.

```bash
sudo -u www-data php /var/www/nextcloud/occ app:enable admin_audit
```

Configuration (extrait — complet dans [`configs/nextcloud/audit.config.php`](../configs/nextcloud/audit.config.php)) :

```php
'logfile'    => '/var/log/nextcloud/audit.log',
'loglevel'   => 1,
'log.condition' => [ 'apps' => ['admin_audit'] ],
```

Exemple de ligne d'audit (réécrite) : *l'utilisateur `mmartin` a téléchargé `/Clients/DURAND/bilan_2025.pdf` le 2026-03-14 à 09:42 depuis 10.20.0.50*. → réponse directe à une demande de la CNIL.

## 9.3 Traçabilité des accès — partages de fichiers AD (NTFS)

Pour les dossiers servis par le serveur de fichiers Windows, on active l'**audit des accès aux objets** :

1. **GPO** : `Configuration ordinateur → Stratégies → Paramètres Windows → Paramètres de sécurité → Stratégies d'audit avancées → Accès aux objets → Auditer le système de fichiers` = Réussite/Échec.
2. **SACL** sur les dossiers sensibles (`Propriétés → Sécurité → Audit`) : groupe *Utilisateurs authentifiés*, actions Lecture/Écriture/Suppression.
3. Les évènements remontent dans le **journal de sécurité** (Event ID 4663, 4670…).

Modèle de GPO documenté dans [`configs/ad/audit-fichiers.gpo.md`](../configs/ad/audit-fichiers.gpo.md).

## 9.4 Traçabilité des accès distants

- **VPN télétravail** : un **certificat nominatif par collaborateur** → les logs OpenVPN (`/var/log/openvpn/rw-status.log`) identifient qui s'est connecté, quand, depuis quelle IP.
- **VPN site-à-site** : journalise les tunnels d'agence.
- Révocation immédiate possible via CRL (départ, perte de matériel).

## 9.5 Centralisation & conservation des journaux

- **Centralisation** : `rsyslog` des passerelles, de Nextcloud et des serveurs vers un collecteur (le serveur Veeam ou une VM dédiée), pour éviter qu'un attaquant n'efface les traces locales.
- **Conservation** : la CNIL recommande une durée de conservation des journaux de connexion **proportionnée**, en pratique souvent **6 mois à 1 an**. On retient **6 mois** pour les journaux d'accès, **12 mois** pour les évènements de sécurité, avec purge automatique au-delà.
- **Protection** : accès aux journaux restreint aux administrateurs ; journaux inclus dans la sauvegarde mais **non modifiables** par les utilisateurs.

## 9.6 Mesures organisationnelles

- **Registre des traitements** (obligation RGPD) : tenir à jour la liste des traitements (paie, compta clients, RH…), finalités, durées, destinataires.
- **Politique d'habilitation** : matrice qui-accède-à-quoi, revue périodiquement (arrivées/départs).
- **Désignation d'un référent / DPO** selon la taille et l'activité.
- **Procédure en cas de violation de données** : notification CNIL sous **72 h** (intégrée au runbook R3, [docs/08](08-pra-pca.md)).
- **Sensibilisation** des collaborateurs (phishing, mots de passe, postes nomades).

## 9.7 Matrice d'habilitation (exemple)

| Groupe AD | Compta clients | Dossiers juridiques | Paie/RH | Espace client Nextcloud |
|---|:---:|:---:|:---:|:---:|
| Comptables | ✅ | — | — | ✅ (clients affectés) |
| Juristes | — | ✅ | — | ✅ (clients affectés) |
| RH | — | — | ✅ | — |
| Direction | ✅ | ✅ | ✅ | ✅ |
| Administrateurs SI | logs only | logs only | logs only | admin |

## 9.8 Réponse-type à un contrôle CNIL

Grâce au dispositif : on peut produire, pour un dossier client donné, **la liste horodatée des accès** (Nextcloud audit + journal NTFS), **prouver le chiffrement** des données au repos et en transit, **présenter la politique de rétention** et le **registre des traitements**, et **démontrer la maîtrise** via le PRA/PCA et les sauvegardes. C'est exactement ce que l'internalisation rendait impossible auparavant.

➡️ Dernière étape : **valider l'ensemble par des tests** ([docs/10](10-tests-recette.md)).
