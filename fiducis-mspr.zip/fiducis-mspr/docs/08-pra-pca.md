# 08 — PRA & PCA

Aujourd'hui : **rien en place**. On formalise un **PCA** (continuité — rester opérationnel pendant l'incident) et un **PRA** (reprise — revenir à la normale après sinistre).

## 8.1 Définitions appliquées

- **PCA — Plan de Continuité d'Activité** : maintenir les fonctions critiques *pendant* un incident (redondance, secours).
- **PRA — Plan de Reprise d'Activité** : restaurer le SI *après* un incident (restauration, bascule, procédures).

## 8.2 Analyse des risques (extrait)

| Risque | Probabilité | Impact | Parade PCA | Parade PRA |
|---|---|---|---|---|
| Coupure Internet d'un site (vécu à La Rochelle) | Élevée | Élevé | Lien de secours 4G/5G + travail local | Reprise au retour du lien |
| Panne du siège (hub) | Moyenne | Critique | DC2 à La Rochelle (auth survit) | Restauration / bascule services |
| Perte de données (suppression, ransomware) | Moyenne | Critique | Sauvegardes immuables | Restauration Veeam |
| Défaillance serveur (matériel/VM) | Moyenne | Moyen | Snapshots, redondance | Restauration bare-metal |
| Compromission du serveur web | Moyenne | Moyen | Isolation DMZ | Réinstallation depuis modèle |

## 8.3 Objectifs RTO / RPO

- **RTO** (Recovery Time Objective) : durée max d'interruption tolérée.
- **RPO** (Recovery Point Objective) : perte de données max tolérée.

| Service | RPO cible | RTO cible | Justification |
|---|---|---|---|
| Sage (compta/paie) | 24 h | 4 h | Sauvegarde quotidienne ; activité reportable d'une demi-journée |
| Nextcloud (fichiers/clients) | 24 h | 4 h | Idem ; pièces clients critiques mais non temps-réel |
| Active Directory / DNS | ~0 (réplication) | < 1 h | DC2 prend le relais quasi immédiatement |
| Site web / espace client | 24 h | 8 h | Image redéployable ; impact commercial modéré |

## 8.4 PCA — dispositifs de continuité

### a) Coupure Internet d'un site

C'est l'incident **réellement vécu**. Le VPN seul **ne suffit pas** (le tunnel a besoin du lien). Dispositif :

1. **Lien de secours par site** : routeur 4G/5G ou 2ᵉ FAI, bascule automatique (failover) sur la passerelle. → le tunnel **remonte** sur le lien de secours, les services restent joignables.
2. **Travail en mode dégradé local** : grâce à l'internalisation et au DC local/secondaire, l'authentification et l'accès aux fichiers récemment synchronisés restent possibles même tunnel coupé.
3. Les softphones VoIP basculent sur données mobiles le temps de la coupure.

> **Note maquette** : faute de matériel 4G, le lien de secours est **documenté et conçu** mais non déployé physiquement. On le **simule** dans VirtualBox en ajoutant une 2ᵉ interface WAN à une passerelle et en coupant la 1ʳᵉ pour démontrer le re-routage. Cf. [docs/10](10-tests-recette.md).

### b) Panne du siège (hub)

- **DC2 à La Rochelle** : l'annuaire et le DNS continuent → les agents peuvent s'authentifier et travailler.
- Les fichiers récents restent disponibles via les copies de sauvegarde à La Rochelle ③.
- Le tunnel hub étant tombé, La Rochelle et Bayonne perdent le routage *inter-sites via le hub* : c'est la limite de l'étoile, acceptée au regard du coût. **Évolution possible** : promouvoir temporairement La Rochelle en hub de secours (config OpenVPN serveur préparée à l'avance, à activer manuellement).

## 8.5 PRA — procédures de reprise (runbooks)

### Runbook R1 — Restauration d'un fichier / dossier client

```
1. Ouvrir la console Veeam sur SRV-VEEAM.
2. Backup Job "Nextcloud" → Restore → Guest files.
3. Sélectionner le point de restauration (date < incident).
4. Restaurer vers l'emplacement d'origine ou un dossier temporaire.
5. Vérifier l'intégrité, notifier l'utilisateur. Consigner au PV.
Cible : RTO < 30 min, RPO < 24 h.
```

### Runbook R2 — Sinistre total du siège Bordeaux

```
1. Déclarer la cellule de crise ; informer la direction.
2. Vérifier que DC2 (La Rochelle) assure l'authentification.
3. Provisionner de nouvelles VM (modèles VirtualBox / OVA conservés hors-site).
4. Restaurer depuis le repository hors-site ③ (La Rochelle) :
   - AD (system state) → DC, si DC2 seul insuffisant
   - Sage, Nextcloud (dernier point sain)
5. Reconfigurer la passerelle de secours (configs versionnées dans ce dépôt /configs).
6. Re-publier le site web depuis son modèle.
7. Tester les accès agences + télétravail. Lever la cellule de crise.
Cible : RTO < 1 jour ouvré pour le périmètre critique.
```

### Runbook R3 — Suspicion de ransomware

```
1. ISOLER : couper les liens inter-sites (stopper les tunnels) pour éviter la propagation.
2. Ne PAS payer ; identifier le périmètre touché.
3. Restaurer depuis une sauvegarde ANTÉRIEURE à l'infection (la copie hors-site/immuable ③).
4. Réinitialiser les identifiants AD, renouveler la PKI VPN si compromission suspectée.
5. Analyse post-incident, déclaration CNIL si données personnelles affectées (72 h).
```

## 8.6 Gouvernance

- **Documentation** : ce dépôt git est la source de vérité (configs, procédures, schémas) — une copie est conservée **hors-ligne**.
- **Tests** : exercices PRA semestriels, tests de restauration mensuels/trimestriels ([docs/07 §7.5](07-sauvegarde-3-2-1.md)).
- **Mise à jour** : le PRA/PCA est révisé à chaque changement majeur (ici : ajout de Bayonne a déclenché une révision).
- **Contacts de crise** : annuaire des responsables + prestataires (FAI, Veeam) maintenu à jour.

## 8.7 Synthèse de la couverture

```mermaid
flowchart TB
    subgraph CONTINUITE["PCA — pendant l'incident"]
        L1["Lien secours 4G/5G par site"]
        L2["DC2 La Rochelle = auth redondée"]
        L3["Services internalisés + sync"]
    end
    subgraph REPRISE["PRA — après l'incident"]
        R1["Sauvegardes 3-2-1 + hors-site"]
        R2["Runbooks R1/R2/R3"]
        R3["Configs versionnées (git)"]
        R4["Tests de restauration réguliers"]
    end
    CONTINUITE --> REPRISE
```

➡️ Reste à répondre formellement au **contrôle CNIL** : [docs/09](09-rgpd-tracabilite.md).
