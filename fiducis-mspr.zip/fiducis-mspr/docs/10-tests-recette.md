# 10 — Tests & recette

Plan de tests validant que la cible répond aux besoins des deux entretiens. Chaque test indique l'objectif, la procédure et le résultat attendu. À l'exécution, on renseigne le **PV de recette** (§10.3).

## 10.1 Tableau des tests

| # | Domaine | Test | Procédure | Résultat attendu |
|---|---|---|---|---|
| T01 | Réseau | Joignabilité WAN | `ping` entre WAN des passerelles | Réponse OK |
| T02 | VPN S2S | Tunnel Bordeaux↔La Rochelle | `cat s2s-status.log` sur le hub | `larochelle` connecté |
| T03 | VPN S2S | Tunnel Bordeaux↔Bayonne | idem | `bayonne` connecté |
| T04 | VPN S2S | LR ↔ Bayonne via hub | `ping 10.30.0.50` depuis 10.20.0.50 | Réponse OK (client-to-client) |
| T05 | VPN S2S | Accès Sage inter-sites | depuis Bayonne, ouvrir Sage sur 10.10.0.40 | Connexion applicative OK |
| T06 | VPN TT | Connexion road-warrior | importer `.ovpn`, se connecter | IP 10.8.0.x obtenue |
| T07 | VPN TT | Accès ressources internes | `ping 10.10.0.10` ; accès Nextcloud | OK ; surf perso reste local (split-tunnel) |
| T08 | VPN TT | Révocation certificat | révoquer + CRL + reconnexion | Connexion refusée |
| T09 | Internalisation | Nextcloud via AD | login avec compte AD | Authentification LDAP OK |
| T10 | Internalisation | Espace client | partage lien protégé à un « client » | Accès limité au dossier partagé |
| T11 | Internalisation | Web en DMZ | accès https au site vitrine | Page servie, HTTPS valide |
| T12 | Cloisonnement | DMZ → LAN interdit | depuis SRV-WEB, `ping 10.10.0.10` | **Échec attendu** (drop) |
| T13 | Sauvegarde | Backup Job incrémental | exécuter le job Nextcloud | Sauvegarde réussie |
| T14 | Sauvegarde | Copie hors-site | Backup Copy Job → La Rochelle | Copie présente sur repo ③ |
| T15 | Restauration | Fichier client | restaurer un fichier supprimé | Fichier récupéré intègre |
| T16 | Traçabilité | Audit Nextcloud | télécharger un fichier, lire `audit.log` | Évènement horodaté + utilisateur |
| T17 | Traçabilité | Audit NTFS | accéder à un dossier audité | Event 4663 dans journal sécurité |
| T18 | PCA | Bascule lien de secours | couper WAN1, activer WAN2 simulé | Tunnel remonte, services OK |
| T19 | PCA | Panne hub | éteindre SRV-AD | DC2 authentifie les postes LR |

## 10.2 Détail de quelques tests clés

### T04 — Communication inter-agences (LR ↔ Bayonne)

```bash
# Depuis CLIENT-LR (10.20.0.50)
ping -c4 10.30.0.50
traceroute 10.30.0.50      # doit passer par 10.99.0.1 (le hub)
```
✔ Démontre que l'étoile + `client-to-client` relie bien les deux branches via le hub.

### T12 — Étanchéité de la DMZ (sécurité)

```bash
# Depuis SRV-WEB (172.16.10.10) — NE DOIT PAS aboutir
ping -c2 10.10.0.10
nc -zv 10.10.0.20 443
```
✔ L'échec **prouve** le cloisonnement : un web compromis n'atteint pas les données clients.

### T15 — Restauration (preuve de sauvegarde utile)

```
1. Supprimer /Clients/TEST/doc.pdf dans Nextcloud.
2. Veeam → Restore guest files → point de la veille.
3. Restaurer, vérifier le checksum.
```
✔ Valide la chaîne 3-2-1 de bout en bout (sauvegarder **et** restaurer).

### T18 — Continuité sur coupure Internet (l'incident vécu)

```
1. Sur GW-LR, désactiver l'interface WAN principale (simule la coupure FAI).
2. Activer l'interface WAN de secours (2ᵉ NIC simulant la 4G).
3. Vérifier que le tunnel site-à-site remonte et que Nextcloud reste joignable.
```
✔ Répond directement au problème de la journée d'arrêt à La Rochelle.

## 10.3 Procès-verbal de recette (modèle)

| # | Date | Opérateur | Résultat | Observations |
|---|---|---|---|---|
| T01 | | | ☐ OK ☐ KO | |
| T02 | | | ☐ OK ☐ KO | |
| … | | | | |

> À compléter lors de la soutenance / démonstration. Un test KO renvoie vers le chapitre concerné pour correction, puis nouveau passage.

## 10.4 Couverture besoins ↔ tests

| Besoin (entretiens) | Tests qui le prouvent |
|---|---|
| Relier les 3 sites en permanence | T02, T03, T04, T05 |
| VPN télétravail (fin de OneDrive nomade) | T06, T07, T08 |
| Internaliser fichiers/web/espace client | T09, T10, T11, T12 |
| Sauvegarde 3-2-1 | T13, T14, T15 |
| Traçabilité CNIL | T16, T17, T08 (nominatif) |
| PRA / PCA | T15, T18, T19 |

➡️ Tous les besoins exprimés lors des deux entretiens sont couverts et vérifiables.
