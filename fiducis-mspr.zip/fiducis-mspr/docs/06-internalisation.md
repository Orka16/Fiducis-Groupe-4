# 06 — Internalisation des services

Décision du 2ᵉ entretien : **tout rapatrier en interne**. On sort de OneDrive/M365 pour les fichiers, et on internalise le **site vitrine**, l'**espace client** et la **prise de rendez-vous**, jusqu'ici chez un prestataire coûteux. Double bénéfice : **réduction des coûts** (objectif business) et **maîtrise/traçabilité** des données (objectif CNIL).

## 6.1 Cartographie avant / après

| Service | Avant | Après |
|---|---|---|
| Fichiers collaboratifs | OneDrive (cloud) | **Nextcloud** `10.10.0.20` (LAN Bordeaux) |
| Espace client | Prestataire web | **Nextcloud** (partages externes sécurisés) |
| Site vitrine | Prestataire web | **Nginx** `172.16.10.10` (DMZ) |
| Prise de rendez-vous | Prestataire web | App de réservation en DMZ (ou Nextcloud Appointments) |
| Identité | AD local | AD local (inchangé, étendu avec DC2) |
| Comptabilité | Sage local | Sage local (inchangé) |
| Messagerie | M365 | **Chantier ultérieur** (cf. §6.5) |

## 6.2 Nextcloud — fichiers et espace client

### Installation (Debian 12, `SRV-NEXTCLOUD`)

Pile LAMP/LEMP : Nginx + PHP-FPM + MariaDB.

```bash
sudo apt install -y nginx mariadb-server php-fpm php-mysql php-gd php-xml \
  php-mbstring php-curl php-zip php-intl php-bcmath php-gmp redis-server php-redis unzip

# Base de données
sudo mysql -e "CREATE DATABASE nextcloud CHARACTER SET utf8mb4;"
sudo mysql -e "CREATE USER 'nc'@'localhost' IDENTIFIED BY 'MotDePasseFort';"
sudo mysql -e "GRANT ALL ON nextcloud.* TO 'nc'@'localhost'; FLUSH PRIVILEGES;"

# Déploiement
cd /var/www && sudo curl -LO https://download.nextcloud.com/server/releases/latest.zip
sudo unzip latest.zip && sudo chown -R www-data:www-data nextcloud
```

Finalisation via l'assistant web, puis durcissement : HTTPS obligatoire (certificat interne ou Let's Encrypt si le site est publié), en-têtes de sécurité, cache Redis.

### Intégration à l'Active Directory (LDAP)

Les collaborateurs se connectent avec **leur compte AD** (pas de double identité) :

```
Application "LDAP / AD integration" → activée
Hôte : 10.10.0.10 (SRV-AD)
Base DN : DC=fiducis,DC=lan
Filtre utilisateur : (&(objectClass=user)(memberOf=CN=Collaborateurs,...))
```

### Espace client (partages externes)

L'espace client se matérialise par des **partages par lien** protégés (mot de passe + expiration) ou des comptes « invité » à droits restreints. Le client dépose/récupère ses pièces sans accès au reste du système. Les **fédérations** et **Guest accounts** confinent chaque client à son dossier.

### Traçabilité (exigence CNIL)

L'app **`admin_audit`** journalise chaque action (lecture, téléchargement, partage, suppression) avec utilisateur + horodatage. Configuration détaillée dans [docs/09](09-rgpd-tracabilite.md) et [`configs/nextcloud/audit.config.php`](../configs/nextcloud/audit.config.php).

### Migration depuis OneDrive

1. Export des données OneDrive de chaque utilisateur (ou via `rclone` OneDrive → local).
2. Import dans l'arborescence Nextcloud correspondante (`occ files:scan`).
3. Déploiement du **client de synchronisation Nextcloud** sur les postes (remplace le client OneDrive).
4. Période de double-run (1–2 semaines) puis bascule, désabonnement OneDrive → **économie**.

```bash
# Réindexation après import massif
sudo -u www-data php /var/www/nextcloud/occ files:scan --all
```

## 6.3 Serveur web en DMZ

Le serveur exposé à Internet est **isolé en DMZ** : compromis, il n'atteint pas le LAN de production.

### Nginx (`SRV-WEB`, 172.16.10.10)

Configuration : [`configs/web/fiducis-vitrine.conf`](../configs/web/fiducis-vitrine.conf).

```nginx
server {
    listen 80;
    server_name www.fiducis.fr;
    return 301 https://$host$request_uri;
}
server {
    listen 443 ssl http2;
    server_name www.fiducis.fr;

    ssl_certificate     /etc/ssl/fiducis/fullchain.pem;
    ssl_certificate_key /etc/ssl/fiducis/privkey.pem;

    # Durcissement
    add_header Strict-Transport-Security "max-age=63072000" always;
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;

    root /var/www/vitrine;
    index index.html;

    # Module prise de rendez-vous (reverse proxy vers l'app interne)
    location /rdv/ {
        proxy_pass http://127.0.0.1:8080/;
        proxy_set_header Host $host;
    }
}
```

### Publication depuis Internet (port-forwarding sur le hub)

Le serveur web étant en DMZ derrière la passerelle Bordeaux, on redirige les ports publics 80/443 vers lui :

```bash
# DNAT sur GW-BDX : Internet:443 -> DMZ 172.16.10.10:443
nft add rule ip nat prerouting iifname "enp0s3" tcp dport {80,443} \
  dnat to 172.16.10.10
# Autoriser le flux WAN -> DMZ uniquement sur 80/443
nft add rule inet fw forward iifname "enp0s3" oifname "enp0s9" \
  tcp dport {80,443} accept
```

### Cloisonnement DMZ ↔ LAN

Règle d'or appliquée dans le pare-feu ([docs/04 §4.4](04-vpn-site-a-site.md)) : la **DMZ ne peut pas initier** de connexion vers le LAN. Si le site web a besoin de données métier, on expose une **API minimale** depuis le LAN vers la DMZ (flux sortant LAN→DMZ contrôlé), jamais l'inverse.

```mermaid
flowchart LR
    INET["Internet"] -->|"80/443"| WEB["SRV-WEB (DMZ)<br/>172.16.10.10"]
    WEB -.->|"❌ interdit"| LAN["LAN production<br/>10.10.0.0/24"]
    LAN -->|"API contrôlée"| WEB
```

## 6.4 Sage

Sage reste sur son serveur dédié (`SRV-SAGE`, 10.10.0.40), désormais :

- **joignable depuis toutes les agences** via le tunnel site-à-site (un comptable de Bayonne accède à Sage à Bordeaux) ;
- **sauvegardé** par Veeam (ce qui n'était pas le cas avant — cf. [docs/07](07-sauvegarde-3-2-1.md)) ;
- limité à **10 utilisateurs simultanés** (contrainte de licence connue) : à surveiller si la charge inter-sites augmente.

## 6.5 Messagerie — chantier ultérieur (transparence)

Auto-héberger la messagerie (Zimbra, Mailcow, Exchange) est techniquement possible mais comporte un **risque opérationnel élevé** : délivrabilité, gestion anti-spam, réputation IP, disponibilité. Pour un cabinet de 35 personnes dont l'email est vital, on **recommande de conserver M365 pour la messagerie** dans un premier temps et de traiter l'internalisation messagerie comme un **projet distinct** avec son propre PRA. Cela n'entre pas en contradiction avec « tout rapatrier » : on rapatrie d'abord ce qui pèse le plus en coût et en risque CNIL (fichiers, web, espace client).

➡️ Les services internalisés génèrent des données qu'il faut **sauvegarder** : [docs/07](07-sauvegarde-3-2-1.md).
