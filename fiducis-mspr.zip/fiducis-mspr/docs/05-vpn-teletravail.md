# 05 — VPN télétravail (road-warrior)

Objectif : permettre aux télétravailleurs (2 j/semaine) d'accéder aux ressources internes **sans OneDrive**, via un tunnel chiffré terminé sur la passerelle de **Bordeaux**. On déploie une **seconde instance** OpenVPN sur le hub, sur un port et un sous-réseau distincts du site-à-site, pour cloisonner les deux usages.

## 5.1 Pourquoi une instance séparée

- Politiques différentes : les nomades ne doivent pas **router** un LAN, seulement **recevoir** des routes.
- Révocation/gestion des certificats utilisateurs indépendante des sites.
- Lisibilité des logs et du filtrage.

| | Site-à-site | Road-warrior |
|---|---|---|
| Port | UDP/1194 | UDP/1195 |
| Sous-réseau | 10.99.0.0/24 | 10.8.0.0/24 |
| Clients | passerelles d'agence | postes nomades |
| Service systemd | `openvpn-server@site2site` | `openvpn-server@roadwarrior` |

## 5.2 Certificats utilisateurs

Sur le hub, dans `~/easyrsa`, un certificat **par collaborateur** (traçabilité individuelle = utile pour la CNIL) :

```bash
./easyrsa gen-req tt-jdupont nopass
./easyrsa sign-req client tt-jdupont
# répéter par utilisateur : tt-mmartin, tt-pdurand, ...
```

> Un certificat nominatif par personne permet de **révoquer** un accès (départ, perte de laptop) sans impacter les autres, et d'**identifier** qui s'est connecté.

## 5.3 Configuration serveur road-warrior

`/etc/openvpn/server/roadwarrior.conf` — complet : [`configs/openvpn/server-roadwarrior.conf`](../configs/openvpn/server-roadwarrior.conf).

```ini
port 1195
proto udp
dev tun

ca       ca.crt
cert     bordeaux.crt
key      bordeaux.key
dh       dh.pem
tls-auth ta.key 0

topology subnet
server 10.8.0.0 255.255.255.0

# Pousser les routes vers TOUS les réseaux internes + la DMZ
push "route 10.10.0.0 255.255.255.0"
push "route 10.20.0.0 255.255.255.0"
push "route 10.30.0.0 255.255.255.0"
push "route 172.16.10.0 255.255.255.0"

# DNS interne (résolution des noms de domaine FIDUCIS)
push "dhcp-option DNS 10.10.0.10"
push "dhcp-option DOMAIN fiducis.lan"

# split-tunnel : seul le trafic interne passe par le VPN
# (pas de redirect-gateway -> le surf perso reste local)

keepalive 10 120
cipher AES-256-GCM
auth SHA256
tls-version-min 1.2
remote-cert-tls client
persist-key
persist-tun
user nobody
group nogroup
status /var/log/openvpn/rw-status.log
verb 3
```

> **Split-tunnel assumé** : on ne force pas tout le trafic du télétravailleur dans le tunnel (`redirect-gateway` absent). Seuls les flux vers les ressources FIDUCIS y passent. Avantage : performances et pas de surcharge du lien du siège. Si la politique de sécurité l'exige (filtrage web centralisé), on basculerait en **full-tunnel** en ajoutant `push "redirect-gateway def1"`.

## 5.4 Profil client `.ovpn` (fichier unique)

On fournit au collaborateur **un seul fichier** intégrant ses certificats (plus simple à importer dans le client OpenVPN GUI / OpenVPN Connect). Modèle : [`configs/openvpn/client-roadwarrior.ovpn`](../configs/openvpn/client-roadwarrior.ovpn).

```ini
client
dev tun
proto udp
remote 203.0.113.11 1195
resolv-retry infinite
nobind
remote-cert-tls server
cipher AES-256-GCM
auth SHA256
tls-version-min 1.2
persist-key
persist-tun
verb 3

<ca>
... contenu de ca.crt ...
</ca>
<cert>
... contenu de tt-jdupont.crt ...
</cert>
<key>
... contenu de tt-jdupont.key ...
</key>
<tls-auth>
... contenu de ta.key ...
</tls-auth>
key-direction 1
```

Le script [`scripts/make-ovpn.sh`](../scripts/make-ovpn.sh) assemble automatiquement ce fichier pour un utilisateur donné.

## 5.5 Pare-feu

Sur le hub, ouvrir le port et autoriser le forwarding du pool nomade vers les LAN/DMZ :

```bash
nft add rule inet fw input udp dport 1195 accept
nft add rule inet fw forward iifname "tun1" accept
nft add rule inet fw forward oifname "tun1" accept
```

*(La seconde instance OpenVPN crée généralement `tun1`.)*

## 5.6 Mise en service et test

```bash
sudo systemctl enable --now openvpn-server@roadwarrior

# Côté poste nomade : importer le .ovpn, se connecter, puis
ping 10.10.0.10              # le contrôleur de domaine répond
nslookup srv-nextcloud.fiducis.lan   # la résolution interne fonctionne
```

## 5.7 Révocation d'un accès (départ / vol de laptop)

```bash
cd ~/easyrsa
./easyrsa revoke tt-jdupont
./easyrsa gen-crl
sudo cp pki/crl.pem /etc/openvpn/server/
# activer la vérification de la CRL dans roadwarrior.conf :
#   crl-verify crl.pem
sudo systemctl restart openvpn-server@roadwarrior
```

➡️ Les nomades disposent d'un accès interne sécurisé et **traçable**. Place à l'**internalisation des services** ([docs/06](06-internalisation.md)).
