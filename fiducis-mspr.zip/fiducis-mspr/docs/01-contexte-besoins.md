# 01 — Contexte & analyse du besoin

## 1.1 L'entreprise

FIDUCIS est un cabinet d'**expertise comptable, juridique et conseil RH** de **35 collaborateurs**. L'activité repose intégralement sur la manipulation de **données clients sensibles** (comptabilité, paie, pièces juridiques), avec une forte exigence de confidentialité et, désormais, de traçabilité.

**Implantations :**

- **Bordeaux** — siège
- **La Rochelle** — agence
- **Bayonne** — nouvelle antenne (issue du 2ᵉ entretien)
- **Télétravail** — régulier, 2 jours / semaine

## 1.2 Existant

| Domaine | Outil actuel | Localisation |
|---|---|---|
| Collaboration / fichiers | Microsoft 365, OneDrive | **Externe (cloud)** |
| Comptabilité / paie | Sage | Local (10 utilisateurs simultanés max) |
| Identité | Active Directory | Windows Server **local** |
| Fichiers | Partages | Serveur **local** |
| Téléphonie | VoIP (softphone télétravail, postes fixes en agence) | Mixte |
| Web | Site vitrine + espace client + prise de RDV | **Externe (prestataire)** |

**Parc :** laptops nomades pour une partie des équipes, scanners haute volumétrie, salles de visioconférence par agence.

## 1.3 Problèmes constatés (fiche de situation)

- Explosion de la volumétrie documentaire (scans, pièces clients).
- Site vitrine et espace client hébergés chez un prestataire **coûteux**.
- Pression RGPD et **traçabilité des accès aux dossiers**.
- **Coupure Internet d'une journée** récente sur le site de La Rochelle.
- **Aucun plan de reprise formalisé.**

## 1.4 Synthèse du 1ᵉʳ entretien

> Le professeur incarnait FIDUCIS. Les réponses ci-dessous orientent directement l'architecture.

**Accès inter-sites / télétravail.** Aujourd'hui : **pas de VPN**, tout passe par OneDrive. Décision :
- **VPN site-à-site** de Bordeaux à La Rochelle pour relier les deux LAN **en permanence** ;
- **VPN client** sur la passerelle de Bordeaux pour les télétravailleurs ;
- techno : **OpenVPN**.

**Impact de la coupure La Rochelle.** Impossible de contacter les clients par mail, uploads impossibles, **OneDrive inaccessible**, télétravail à l'arrêt — activité totalement bloquée. Le VPN est attendu comme une partie de la réponse.

**Politique de sauvegarde.** Aucune aujourd'hui (ni OneDrive, ni Sage). Décision :
- règle **3-2-1** (3 copies, 2 supports différents, 1 hors-site) ;
- **Veeam** en sauvegarde **incrémentale**, exploitable sur les deux sites grâce au VPN site-à-site.

**Données critiques.** **Tout** est considéré sensible — niveau de protection maximal sur l'ensemble.

**PRA / PCA.** **Rien en place.** Décision : **mettre en place un PRA et un PCA**.

## 1.5 Synthèse du 2ᵉ entretien (ajouts)

- **Nouvelle antenne à Bayonne** → à intégrer au VPN inter-sites (l'étoile passe de 2 à 3 branches).
- **Contrôle CNIL** → besoin de **traçabilité des accès aux données clients** (qui accède à quel dossier, quand).
- **Tout rapatrier en interne** → sortie de OneDrive/M365 pour les fichiers et internalisation du site web et de l'espace client.

## 1.6 Objectifs retenus pour la cible

1. **Interconnexion permanente** des 3 sites (VPN site-à-site en étoile, hub Bordeaux).
2. **Accès distant sécurisé** pour les télétravailleurs (VPN client).
3. **Internalisation** des fichiers (Nextcloud) et du web (vitrine + espace client + RDV) en **DMZ**.
4. **Sauvegarde 3-2-1** avec Veeam, dont une copie hors-site.
5. **PRA/PCA** documentés et **testés**.
6. **Traçabilité** des accès aux données clients (exigence CNIL).
7. **Réduction des coûts** d'hébergement externe (objectif business).

## 1.7 Contraintes & hypothèses

- **Virtualisation imposée : VirtualBox.** La redondance de lien Internet (4G/5G, second FAI) est **recommandée dans le PRA** mais simulée/documentée plutôt que réellement déployée, faute de moyens matériels — cf. [docs/08](08-pra-pca.md).
- Sage est conservé tel quel sur un serveur dédié ; seules sa sauvegarde et sa joignabilité inter-sites sont traitées.
- La messagerie : dans une logique « tout en interne » on pourrait l'auto-héberger, mais c'est un projet à fort risque opérationnel (réputation IP, anti-spam). **Choix assumé** : on internalise fichiers + web + espace client (gros postes de coût et de risque CNIL), et on documente la messagerie comme **chantier ultérieur**. Cf. [docs/06](06-internalisation.md).

## 1.8 Point de vigilance signalé au client

Un VPN **ne compense pas** une coupure Internet : le tunnel a lui-même besoin du lien pour monter. La continuité réelle face à une panne FAI repose sur un **lien de secours par site** + des **services internalisés** joignables via le tunnel. Ce point structure le PRA/PCA ([docs/08](08-pra-pca.md)).
