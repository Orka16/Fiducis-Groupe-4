# 03 — Maquette VirtualBox

## 3.1 Inventaire des machines virtuelles

| VM | OS | vCPU | RAM | Disque | Réseaux (NIC1 / NIC2 / NIC3) |
|---|---|---|---|---|---|
| `GW-BDX` | Debian 12 | 1 | 512 Mo | 8 Go | NAT `inet-sim` / Internal `lan-bdx` / Internal `dmz-bdx` |
| `GW-LR` | Debian 12 | 1 | 512 Mo | 8 Go | NAT `inet-sim` / Internal `lan-lr` |
| `GW-BAY` | Debian 12 | 1 | 512 Mo | 8 Go | NAT `inet-sim` / Internal `lan-bay` |
| `SRV-AD` | Windows Server 2022 | 2 | 2048 Mo | 40 Go | Internal `lan-bdx` |
| `SRV-NEXTCLOUD` | Debian 12 | 2 | 2048 Mo | 30 Go | Internal `lan-bdx` |
| `SRV-VEEAM` | Windows Server 2022 | 2 | 4096 Mo | 60 Go | Internal `lan-bdx` |
| `SRV-WEB` | Debian 12 | 1 | 512 Mo | 10 Go | Internal `dmz-bdx` |
| `SRV-SAGE` | Windows Server 2022 | 2 | 2048 Mo | 40 Go | Internal `lan-bdx` |
| `SRV-DC2` | Windows Server 2022 (Core) | 2 | 2048 Mo | 40 Go | Internal `lan-lr` |
| `CLIENT-LR` | Windows 10/11 | 2 | 2048 Mo | 40 Go | Internal `lan-lr` |
| `CLIENT-BAY` | Windows 10/11 | 2 | 2048 Mo | 40 Go | Internal `lan-bay` |

### Budget RAM et fonctionnement par scénarios

L'ensemble pèse ~20 Go de RAM si tout tourne en même temps — rarement nécessaire. **On démarre les VM par groupe selon la démo :**

- **Scénario VPN inter-sites** : `GW-BDX`, `GW-LR`, `GW-BAY`, `CLIENT-LR`, `CLIENT-BAY` (~6 Go).
- **Scénario services internes** : `GW-BDX`, `SRV-AD`, `SRV-NEXTCLOUD`, `SRV-WEB`, un client (~7 Go).
- **Scénario sauvegarde** : `SRV-VEEAM` + cibles (~8 Go).

Astuces VirtualBox pour tenir : Windows Server en **édition Core** (sans GUI), `--paravirtprovider default`, désactivation de l'audio/USB inutiles, disques **dynamiques**.

## 3.2 Schéma de câblage virtuel

```mermaid
flowchart LR
    NAT(("NAT Network<br/>inet-sim<br/>203.0.113.0/24"))

    GWB["GW-BDX"]:::gw
    GWL["GW-LR"]:::gw
    GWY["GW-BAY"]:::gw

    NAT --- GWB
    NAT --- GWL
    NAT --- GWY

    LANB(("Internal<br/>lan-bdx")):::net
    DMZB(("Internal<br/>dmz-bdx")):::net
    LANL(("Internal<br/>lan-lr")):::net
    LANY(("Internal<br/>lan-bay")):::net

    GWB --- LANB
    GWB --- DMZB
    GWL --- LANL
    GWY --- LANY

    LANB --- AD["SRV-AD"] & NC["SRV-NEXTCLOUD"] & VE["SRV-VEEAM"] & SG["SRV-SAGE"]
    DMZB --- WB["SRV-WEB"]
    LANL --- DC2["SRV-DC2"] & C1["CLIENT-LR"]
    LANY --- C2["CLIENT-BAY"]

    classDef gw fill:#e67e22,color:#fff;
    classDef net fill:#2c3e50,color:#fff;
```

## 3.3 Création des réseaux

Le **NAT Network** simule Internet : les VM s'y voient entre elles **et** atteignent le vrai Internet (pratique pour `apt`). On lui force la plage `203.0.113.0/24`.

```bash
# Réseau "Internet"
VBoxManage natnetwork add --netname inet-sim \
  --network "203.0.113.0/24" --enable --dhcp off

# Les Internal Networks (lan-bdx, dmz-bdx, lan-lr, lan-bay) n'ont pas
# besoin d'être créés au préalable : ils existent dès qu'une VM s'y attache.
```

> DHCP désactivé sur le NAT Network : on attribue les WAN en **statique** côté invité (203.0.113.11/12/13) pour avoir des « IP publiques » stables que les clients OpenVPN ciblent.

## 3.4 Provisioning des VM (exemple passerelle Bordeaux)

```bash
VM="GW-BDX"
VBoxManage createvm --name "$VM" --ostype Debian_64 --register
VBoxManage modifyvm "$VM" --memory 512 --cpus 1 --paravirtprovider default
VBoxManage createhd --filename "$HOME/VirtualBox VMs/$VM/$VM.vdi" --size 8000 --variant Standard
VBoxManage storagectl "$VM" --name SATA --add sata --controller IntelAhci
VBoxManage storageattach "$VM" --storagectl SATA --port 0 --device 0 --type hdd \
  --medium "$HOME/VirtualBox VMs/$VM/$VM.vdi"
VBoxManage storageattach "$VM" --storagectl SATA --port 1 --device 0 --type dvddrive \
  --medium "$HOME/iso/debian-12-netinst.iso"

# NIC1 = WAN (NAT Network), NIC2 = LAN, NIC3 = DMZ
VBoxManage modifyvm "$VM" --nic1 natnetwork --nat-network1 inet-sim
VBoxManage modifyvm "$VM" --nic2 intnet --intnet2 lan-bdx
VBoxManage modifyvm "$VM" --nic3 intnet --intnet3 dmz-bdx
```

L'ensemble est automatisé dans [`scripts/provision-virtualbox.sh`](../scripts/provision-virtualbox.sh).

## 3.5 Configuration réseau des invités

### Passerelle Bordeaux — `/etc/network/interfaces`

```ini
# NIC1 — WAN (Internet simulé)
auto enp0s3
iface enp0s3 inet static
    address 203.0.113.11/24
    gateway 203.0.113.1          # passerelle du NAT Network VirtualBox

# NIC2 — LAN Bordeaux
auto enp0s8
iface enp0s8 inet static
    address 10.10.0.254/24

# NIC3 — DMZ
auto enp0s9
iface enp0s9 inet static
    address 172.16.10.254/24
```

### Activation du routage (toutes les passerelles)

```bash
# /etc/sysctl.d/99-routing.conf
net.ipv4.ip_forward = 1
```
```bash
sudo sysctl --system
```

### Exemple serveur LAN (Nextcloud) — `/etc/network/interfaces`

```ini
auto enp0s3
iface enp0s3 inet static
    address 10.10.0.20/24
    gateway 10.10.0.254          # la passerelle du site
    dns-nameservers 10.10.0.10   # le contrôleur de domaine / DNS
```

## 3.6 Vérifications de base

```bash
# Depuis la passerelle Bordeaux : Internet OK ?
ping -c2 deb.debian.org

# Depuis un serveur du LAN : sortie Internet via la passerelle ?
ping -c2 10.10.0.254 && ping -c2 1.1.1.1

# Les WAN des passerelles se voient-elles (avant VPN) ?
ping -c2 203.0.113.12     # depuis GW-BDX vers GW-LR
```

Une fois ces points validés, on passe à la **PKI et au VPN site-à-site** ([docs/04](04-vpn-site-a-site.md)).
