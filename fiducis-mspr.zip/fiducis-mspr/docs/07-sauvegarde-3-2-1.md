# 07 — Sauvegarde 3-2-1 (Veeam)

Aujourd'hui : **aucune sauvegarde** (ni OneDrive, ni Sage). On met en place la règle **3-2-1** avec **Veeam**, en tirant parti du tunnel site-à-site pour la copie hors-site.

## 7.1 La règle 3-2-1 appliquée à FIDUCIS

> **3** copies des données · **2** supports différents · **1** copie hors-site.

```mermaid
flowchart LR
    PROD["① Données de production<br/>AD, Nextcloud, Sage, Web<br/>(Bordeaux)"]
    LOCAL["② Sauvegarde locale<br/>Repository Veeam<br/>disque dédié SRV-VEEAM"]
    OFF["③ Copie hors-site<br/>Repository La Rochelle<br/>via VPN site-à-site"]

    PROD -->|"Backup Job (incrémental)"| LOCAL
    LOCAL -->|"Backup Copy Job"| OFF
```

| Copie | Emplacement | Support | Rôle |
|---|---|---|---|
| ① Production | Serveurs Bordeaux | Disques de prod | Données vivantes |
| ② Sauvegarde | `SRV-VEEAM` (10.10.0.30), volume dédié | Disque secondaire | Restauration rapide locale |
| ③ Hors-site | Repository à **La Rochelle** | Disque distant (via VPN) | Survie à un sinistre Bordeaux |

> **2 supports différents** : la copie ② est sur un volume **distinct** des disques de production ; la copie ③ est sur un **autre site physique**. Pour aller plus loin (vrai 3ᵉ média), on peut ajouter une cible **immuable** (repository Linux hardened / objet S3 worm) — recommandé mais hors maquette.

## 7.2 Architecture Veeam

- **Veeam Backup & Replication** sur `SRV-VEEAM` (Windows Server) = serveur de sauvegarde + repository local ②.
- **Veeam Agent for Linux** sur `SRV-NEXTCLOUD` et les passerelles (sauvegarde des configs OpenVPN/nftables).
- **VM Windows (AD, Sage)** sauvegardées au niveau agent également (la maquette est en VirtualBox ; en production VMware/Hy-V on ferait du backup image-level agentless).
- **Repository hors-site** à La Rochelle : un volume sur `SRV-DC2` ou une petite VM de stockage, atteint via le **tunnel** (`10.20.0.0/24`).

## 7.3 Politique de rétention (proposition)

| Jeu de données | Fréquence | Type | Rétention locale | Hors-site |
|---|---|---|---|---|
| Sage (compta/paie) | Quotidienne | Incrémental | 30 jours | 90 jours |
| Nextcloud (fichiers/clients) | Quotidienne | Incrémental | 30 jours | 90 jours |
| AD / DNS (system state) | Quotidienne | Incrémental | 15 jours | 30 jours |
| Configs passerelles / web | Hebdomadaire | Complet | 8 semaines | 8 semaines |
| Synthèse mensuelle (archivage légal) | Mensuelle | Complet (GFS) | 12 mois | 12 mois |

Schéma **GFS** (Grandfather-Father-Son) : rétentions journalières + hebdo + mensuelles pour couvrir l'obligation de conservation comptable sans saturer le stockage.

## 7.4 Mise en œuvre (résumé)

1. **Repository local** : ajouter un disque dédié à `SRV-VEEAM`, le déclarer comme *Backup Repository*.
2. **Backup Jobs** : un job par périmètre (Sage, Nextcloud, AD, configs), planifiés la nuit, mode **incrémental** avec **synthetic full** hebdomadaire.
3. **Repository hors-site** : déclarer le volume de La Rochelle (accessible via VPN) comme second repository.
4. **Backup Copy Job** : copie automatique ② → ③ après chaque sauvegarde réussie (bande passante du tunnel limitée la nuit si besoin via *throttling*).
5. **Chiffrement** des sauvegardes activé (AES-256) — les données restent sensibles même hors-site.
6. **Notifications** mail en cas d'échec.

## 7.5 Tests de restauration (le maillon manquant aujourd'hui)

Une sauvegarde non testée n'est pas une sauvegarde. On planifie :

| Test | Fréquence | Critère de succès |
|---|---|---|
| Restauration d'un fichier client Nextcloud | Mensuelle | Fichier récupéré, intègre, < 30 min |
| Restauration d'une base Sage | Trimestrielle | Base montée et cohérente, < 4 h |
| Restauration AD (system state / objet) | Trimestrielle | Objet/compte restauré |
| Bare-metal d'un serveur complet | Semestrielle | Serveur opérationnel, < RTO cible |

Chaque test fait l'objet d'un **procès-verbal** daté (cf. [docs/10](10-tests-recette.md)). Veeam **SureBackup** peut automatiser la vérification en démarrant les sauvegardes dans un bac à sable isolé.

## 7.6 Lien avec le PRA/PCA

Les copies ② (rapide) et ③ (hors-site) alimentent directement les procédures de reprise : restauration locale pour un incident isolé, bascule sur La Rochelle pour un sinistre Bordeaux. Détail dans [docs/08](08-pra-pca.md).

➡️ On peut désormais restaurer ce qui doit l'être ; reste à **organiser la continuité et la reprise** : [docs/08](08-pra-pca.md).
